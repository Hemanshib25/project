import PapersList from '../PapersList';

export default function PapersListExample() {
  return (
    <div className="p-8">
      <PapersList />
    </div>
  );
}
