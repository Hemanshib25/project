import SyllabusBrowser from '../SyllabusBrowser';

export default function SyllabusBrowserExample() {
  return (
    <div className="p-8">
      <SyllabusBrowser />
    </div>
  );
}
