import ChatInterface from '../ChatInterface';

export default function ChatInterfaceExample() {
  return (
    <div className="h-screen">
      <ChatInterface />
    </div>
  );
}
