import Team from '../Team';

export default function TeamExample() {
  return <Team />;
}
